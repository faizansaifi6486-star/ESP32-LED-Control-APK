package com.example.esp32ledcontrol

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothSocket
import android.os.Handler
import android.os.Looper
import java.io.IOException
import java.io.OutputStream
import java.util.UUID
import java.util.concurrent.Executors

enum class ConnectionState { DISCONNECTED, CONNECTING, CONNECTED }

/**
 * Bluetooth Classic (RFCOMM / SPP) client.
 *
 * - All listener callbacks are delivered on the main thread.
 * - Every Bluetooth error is caught and reported through the listener; nothing is thrown to the UI.
 * - Call every public method from the main thread.
 *
 * Only BLUETOOTH_CONNECT (Android 12+) / BLUETOOTH (Android 10-11) is needed: we never scan,
 * we only connect to already-paired devices, so no location or BLUETOOTH_SCAN permission is used.
 */
@SuppressLint("MissingPermission") // The caller checks the permission before using this class.
class BluetoothController(private val listener: Listener) {

    interface Listener {
        fun onStateChanged(state: ConnectionState, message: String?, isError: Boolean)
        fun onLine(line: String)
    }

    companion object {
        /** Standard Serial Port Profile UUID. */
        val SPP_UUID: UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
    }

    private val main = Handler(Looper.getMainLooper())
    private val writer = Executors.newSingleThreadExecutor()

    @Volatile private var socket: BluetoothSocket? = null
    @Volatile private var out: OutputStream? = null

    /** Incremented on every connect/disconnect so callbacks from stale threads are ignored. */
    @Volatile private var session = 0

    var state: ConnectionState = ConnectionState.DISCONNECTED
        private set

    /** The last device we tried to connect to; used by Reconnect. */
    var lastDevice: BluetoothDevice? = null
        private set

    fun connect(device: BluetoothDevice) {
        if (state == ConnectionState.CONNECTING) return
        closeSocket()
        lastDevice = device
        val id = ++session
        setState(ConnectionState.CONNECTING, "Connecting…", false)
        Thread({ connectAndRead(device, id) }, "bt-connect-read").start()
    }

    fun disconnect() {
        session++
        closeSocket()
        if (state != ConnectionState.DISCONNECTED) {
            setState(ConnectionState.DISCONNECTED, "Disconnected", false)
        }
    }

    /** Queues one command character. Returns false if not connected. */
    fun send(command: Char): Boolean {
        val stream = out
        if (state != ConnectionState.CONNECTED || stream == null) return false
        val id = session
        writer.execute {
            try {
                stream.write(command.code)
                stream.flush()
            } catch (e: Exception) {
                handleLost(id, "Send failed – connection lost")
            }
        }
        return true
    }

    fun shutdown() {
        session++
        closeSocket()
        writer.shutdownNow()
    }

    // ---- internals -------------------------------------------------------------------------

    private fun connectAndRead(device: BluetoothDevice, id: Int) {
        var connected: BluetoothSocket? = null
        try {
            connected = try {
                open(device, id, secure = true)
            } catch (first: IOException) {
                if (id != session) return
                // Some ESP32 / phone combinations only work with an insecure RFCOMM socket.
                open(device, id, secure = false)
            }
        } catch (e: Exception) {
            handleLost(id, "Could not connect. Check the ESP32 is powered, paired and in range.")
            return
        }
        if (id != session) {
            connected.closeQuietly()
            return
        }

        out = connected.outputStream
        main.post {
            if (id == session) setState(ConnectionState.CONNECTED, "Connected", false)
        }

        try {
            val input = connected.inputStream
            val buf = ByteArray(256)
            val line = StringBuilder()
            while (true) {
                val n = input.read(buf)
                if (n < 0) throw IOException("Stream closed")
                for (i in 0 until n) {
                    val ch = (buf[i].toInt() and 0xFF).toChar()
                    if (ch == '\n' || ch == '\r') {
                        if (line.isNotBlank()) emit(line.toString().trim(), id)
                        line.setLength(0)
                    } else if (line.length < 512) {
                        line.append(ch)
                    }
                }
            }
        } catch (e: Exception) {
            handleLost(id, "Connection lost")
        }
    }

    private fun open(device: BluetoothDevice, id: Int, secure: Boolean): BluetoothSocket {
        val s = if (secure) device.createRfcommSocketToServiceRecord(SPP_UUID)
        else device.createInsecureRfcommSocketToServiceRecord(SPP_UUID)
        socket = s // stored first so disconnect() can abort a pending connect()
        try {
            s.connect()
        } catch (e: IOException) {
            s.closeQuietly()
            throw e
        }
        return s
    }

    private fun emit(line: String, id: Int) {
        main.post { if (id == session) listener.onLine(line) }
    }

    /** Reports a dropped/failed connection once, then ignores any further errors of that session. */
    private fun handleLost(id: Int, message: String) {
        main.post {
            if (id == session && state != ConnectionState.DISCONNECTED) {
                session++
                closeSocket()
                setState(ConnectionState.DISCONNECTED, message, true)
            }
        }
    }

    private fun setState(newState: ConnectionState, message: String?, isError: Boolean) {
        state = newState
        listener.onStateChanged(newState, message, isError)
    }

    private fun closeSocket() {
        socket.closeQuietly()
        socket = null
        out = null
    }

    private fun BluetoothSocket?.closeQuietly() {
        try { this?.close() } catch (_: Exception) { }
    }
}
