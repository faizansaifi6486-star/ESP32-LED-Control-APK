package com.example.esp32ledcontrol

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.example.esp32ledcontrol.databinding.ActivityMainBinding
import com.google.android.material.snackbar.Snackbar
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@SuppressLint("MissingPermission") // Every Bluetooth call is guarded by hasBtPermission().
class MainActivity : AppCompatActivity(), BluetoothController.Listener {

    private companion object {
        const val TARGET_NAME = "ESP32_LED_CONTROL"
        const val MAX_LOG_CHARS = 8000
    }

    private lateinit var b: ActivityMainBinding
    private lateinit var controller: BluetoothController
    private var btAdapter: BluetoothAdapter? = null
    private var devices: List<BluetoothDevice> = emptyList()
    private var snack: Snackbar? = null
    private val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.US)

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) loadPairedDevices(promptEnable = true)
            else showHint("Nearby devices permission is required. Tap “Pair / Settings” to grant it.")
        }

    private val enableBluetoothLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) {
            loadPairedDevices(promptEnable = false)
        }

    // ---- lifecycle -------------------------------------------------------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        controller = BluetoothController(this)
        btAdapter = (getSystemService(BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter

        setupButtons()
        renderState(ConnectionState.DISCONNECTED)

        if (btAdapter == null) {
            showHint("This device does not support Bluetooth.")
            b.btnRefresh.isEnabled = false
            b.btnConnect.isEnabled = false
        } else {
            loadPairedDevices(promptEnable = true)
        }
    }

    override fun onResume() {
        super.onResume()
        // The user may have just paired the ESP32 in system settings.
        if (btAdapter != null && controller.state == ConnectionState.DISCONNECTED && hasBtPermission()) {
            loadPairedDevices(promptEnable = false)
        }
    }

    override fun onDestroy() {
        controller.shutdown()
        super.onDestroy()
    }

    // ---- UI setup --------------------------------------------------------------------------

    private fun setupButtons() {
        val commands = mapOf(
            b.btnLed1On to '1', b.btnLed1Off to '2',
            b.btnLed2On to '3', b.btnLed2Off to '4',
            b.btnBuzzerOn to '5', b.btnBuzzerOff to '6',
            b.btnAllOn to 'A', b.btnAllOff to 'B'
        )
        commands.forEach { (button, cmd) -> button.setOnClickListener { sendCommand(cmd) } }

        b.btnRefresh.setOnClickListener { loadPairedDevices(promptEnable = true) }
        b.btnSettings.setOnClickListener {
            if (!hasBtPermission()) openAppSettings()
            else startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS))
        }
        b.btnConnect.setOnClickListener {
            val device = devices.getOrNull(b.spinnerDevices.selectedItemPosition)
            if (device == null) toast("Select a paired device first") else connectTo(device)
        }
        b.btnReconnect.setOnClickListener { reconnect() }
        b.btnDisconnect.setOnClickListener { controller.disconnect() }
        b.btnClearLog.setOnClickListener {
            b.tvLog.text = ""
            b.tvFeedback.text = "—"
        }
    }

    private val controlButtons: List<Button>
        get() = listOf(
            b.btnLed1On, b.btnLed1Off, b.btnLed2On, b.btnLed2Off,
            b.btnBuzzerOn, b.btnBuzzerOff, b.btnAllOn, b.btnAllOff
        )

    private fun renderState(state: ConnectionState) {
        val connected = state == ConnectionState.CONNECTED
        val disconnected = state == ConnectionState.DISCONNECTED

        when (state) {
            ConnectionState.CONNECTED -> {
                b.tvStatus.text = "● Connected"
                b.tvStatus.setTextColor(ContextCompat.getColor(this, R.color.status_connected))
            }
            ConnectionState.CONNECTING -> {
                b.tvStatus.text = "● Connecting…"
                b.tvStatus.setTextColor(ContextCompat.getColor(this, R.color.status_connecting))
            }
            ConnectionState.DISCONNECTED -> {
                b.tvStatus.text = "● Disconnected"
                b.tvStatus.setTextColor(ContextCompat.getColor(this, R.color.status_disconnected))
            }
        }

        controlButtons.forEach { it.isEnabled = connected }          // safety: only when connected
        b.btnDisconnect.isEnabled = !disconnected
        b.btnConnect.isEnabled = disconnected && devices.isNotEmpty()
        b.btnReconnect.isEnabled = disconnected && controller.lastDevice != null
        b.spinnerDevices.isEnabled = disconnected && devices.isNotEmpty()
        b.btnRefresh.isEnabled = disconnected

        if (state != ConnectionState.DISCONNECTED) {
            snack?.dismiss()
            snack = null
        }
    }

    // ---- Bluetooth flow --------------------------------------------------------------------

    private fun hasBtPermission(): Boolean =
        Build.VERSION.SDK_INT < Build.VERSION_CODES.S ||
            ContextCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) ==
            PackageManager.PERMISSION_GRANTED

    private fun loadPairedDevices(promptEnable: Boolean) {
        val adapter = btAdapter ?: return

        if (!hasBtPermission()) {
            // Android 12+ "Nearby devices" runtime permission.
            permissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
            return
        }
        if (!adapter.isEnabled) {
            showHint("Bluetooth is turned off.")
            setDevices(emptyList())
            if (promptEnable) {
                try {
                    enableBluetoothLauncher.launch(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE))
                } catch (e: Exception) {
                    toast("Please turn Bluetooth on in system settings")
                }
            }
            return
        }

        val previouslySelected = devices.getOrNull(b.spinnerDevices.selectedItemPosition)?.address
        val paired = try {
            adapter.bondedDevices.orEmpty().sortedBy { (it.name ?: "").lowercase() }
        } catch (e: SecurityException) {
            emptyList()
        }
        setDevices(paired, previouslySelected)

        showHint(
            when {
                paired.isEmpty() -> "No paired devices. Tap “Pair / Settings” and pair $TARGET_NAME first."
                paired.none { it.name == TARGET_NAME } ->
                    "$TARGET_NAME is not paired yet. Tap “Pair / Settings” to pair it."
                else -> "Select $TARGET_NAME and tap Connect."
            }
        )
    }

    private fun setDevices(list: List<BluetoothDevice>, keepAddress: String? = null) {
        devices = list
        val labels = list.map { deviceLabel(it) }
        b.spinnerDevices.adapter =
            ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, labels)

        val preferred = list.indexOfFirst { it.address == keepAddress }.takeIf { it >= 0 }
            ?: list.indexOfFirst { it.name == TARGET_NAME }.takeIf { it >= 0 }
            ?: 0
        if (list.isNotEmpty()) b.spinnerDevices.setSelection(preferred)
        renderState(controller.state)
    }

    private fun deviceLabel(d: BluetoothDevice): String = try {
        "${d.name ?: "Unknown"}\n${d.address}"
    } catch (e: SecurityException) {
        "Unknown device"
    }

    private fun connectTo(device: BluetoothDevice) {
        if (!hasBtPermission()) {
            permissionLauncher.launch(Manifest.permission.BLUETOOTH_CONNECT)
            return
        }
        if (btAdapter?.isEnabled != true) {
            loadPairedDevices(promptEnable = true)
            return
        }
        controller.connect(device)
    }

    private fun reconnect() {
        controller.lastDevice?.let { connectTo(it) }
    }

    private fun sendCommand(cmd: Char) {
        if (controller.send(cmd)) appendLog("→ $cmd") else toast("Not connected")
    }

    // ---- BluetoothController.Listener ------------------------------------------------------

    override fun onStateChanged(state: ConnectionState, message: String?, isError: Boolean) {
        renderState(state)
        message?.let { appendLog("● $it") }
        if (isError && controller.lastDevice != null) {
            snack = Snackbar.make(b.root, message ?: "Connection problem", Snackbar.LENGTH_INDEFINITE)
                .setAction("Reconnect") { reconnect() }
                .also { it.show() }
        }
    }

    override fun onLine(line: String) {
        b.tvFeedback.text = line
        appendLog("ESP32: $line")
    }

    // ---- helpers ---------------------------------------------------------------------------

    private fun appendLog(text: String) {
        val updated = b.tvLog.text.toString() + "${timeFormat.format(Date())}  $text\n"
        b.tvLog.text = if (updated.length > MAX_LOG_CHARS) updated.takeLast(MAX_LOG_CHARS) else updated
        b.scrollLog.post { b.scrollLog.fullScroll(View.FOCUS_DOWN) }
    }

    private fun showHint(text: String) {
        b.tvHint.text = text
    }

    private fun openAppSettings() {
        startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", packageName, null))
        )
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()
}
