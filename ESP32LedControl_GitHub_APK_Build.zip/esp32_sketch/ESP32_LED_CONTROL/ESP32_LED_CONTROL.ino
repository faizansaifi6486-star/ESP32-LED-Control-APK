// ESP32 side for the ESP32LedControl Android app (Bluetooth Classic SPP).
// Board: any classic ESP32 (ESP32-S3 / C3 / C6 have NO Bluetooth Classic).
// Library: BluetoothSerial (bundled with the Arduino-ESP32 core).

#include "BluetoothSerial.h"

#if !defined(CONFIG_BT_ENABLED) || !defined(CONFIG_BLUEDROID_ENABLED)
#error Bluetooth is not enabled! Use a classic ESP32 board.
#endif

BluetoothSerial SerialBT;

const int LED1_PIN   = 2;   // on-board LED on many boards
const int LED2_PIN   = 4;
const int BUZZER_PIN = 5;   // active buzzer

void setAll(bool on) {
  digitalWrite(LED1_PIN, on);
  digitalWrite(LED2_PIN, on);
  digitalWrite(BUZZER_PIN, on);
}

void reply(const char *text) {
  SerialBT.println(text);   // the app reads one response per line
  Serial.println(text);
}

void setup() {
  Serial.begin(115200);
  pinMode(LED1_PIN, OUTPUT);
  pinMode(LED2_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  setAll(false);

  SerialBT.begin("ESP32_LED_CONTROL");
  Serial.println("Bluetooth ready. Pair with ESP32_LED_CONTROL.");
}

void loop() {
  while (SerialBT.available()) {
    char c = (char)SerialBT.read();
    switch (c) {
      case '1': digitalWrite(LED1_PIN, HIGH);   reply("LED 1 ON");    break;
      case '2': digitalWrite(LED1_PIN, LOW);    reply("LED 1 OFF");   break;
      case '3': digitalWrite(LED2_PIN, HIGH);   reply("LED 2 ON");    break;
      case '4': digitalWrite(LED2_PIN, LOW);    reply("LED 2 OFF");   break;
      case '5': digitalWrite(BUZZER_PIN, HIGH); reply("BUZZER ON");   break;
      case '6': digitalWrite(BUZZER_PIN, LOW);  reply("BUZZER OFF");  break;
      case 'A': setAll(true);                   reply("ALL ON");      break;
      case 'B': setAll(false);                  reply("ALL OFF");     break;
      default: break;   // ignore \r, \n and anything unknown
    }
  }
  delay(5);
}
